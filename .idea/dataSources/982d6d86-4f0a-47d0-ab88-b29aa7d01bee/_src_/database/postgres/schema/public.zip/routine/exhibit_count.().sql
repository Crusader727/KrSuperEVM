create function exhibit_count() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE Exhibition
  SET exhibitCount = Exhibition.exhibitCount + 1
  WHERE Exhibition.id = new.exhibiton_id;
  RETURN new;
END;
$$;
