create function set_forumid_inthread() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE thread
  SET forumid = (SELECT id from forum where lower(forum.slug) = lower(new.forum))
  WHERE lower(forum.slug) = lower(new.forum);
  RETURN new;
END;
$$;
