create function staff_count() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE Museums
  SET staffCount = staffCount + 1
  WHERE Museums.id = new.museum_id;
  RETURN new;
END;
$$;
