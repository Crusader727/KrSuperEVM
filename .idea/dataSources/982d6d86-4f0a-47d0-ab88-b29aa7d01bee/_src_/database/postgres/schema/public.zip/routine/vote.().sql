create function vote() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        IF (TG_OP = 'INSERT')
        THEN
                UPDATE thread
                SET votes = votes + new.votes
                WHERE thread.tid = new.threadid;
                RETURN new;
        ELSE
                IF new.votes != old.votes
                THEN
                        UPDATE thread
                        SET votes = votes + (new.votes * 2)
                        WHERE thread.tid = new.threadid;
                        RETURN new;
                END IF;
                RETURN new;
        END IF;
END;
$$;
