create function forum_threads_inc() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        new.forumid = (SELECT id from forum where lower(forum.slug) = lower(new.forum));
        UPDATE forum
        SET threadCount = threadCount + 1
        WHERE forum.id = new.forumid;
        INSERT INTO users_on_forum (nickname, forumid, fullname, email, about)
                (SELECT
                         new.owner,
                         new.forumid,
                         u.fullname,
                         u.email,
                         u.about
                 FROM users u
                 WHERE lower(new.owner) = lower(u.nickname))
        ON CONFLICT DO NOTHING;
        --   UPDATE thread
        --   SET forumid = (SELECT id from forum where lower(forum.slug) = lower(new.forum))
        --   WHERE lower(forum.slug) = lower(new.forum);
        RETURN new;
END;
$$;
